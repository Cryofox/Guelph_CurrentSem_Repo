To Compile: make, make all, make cflatc
To Comp & run: make run
To Clean: make clean

To Draw Graph:
dot -Tps ./Tree.abs -o Test.ps 

Everything works as needed. Most of the effort is in converting IR code
and figuring how to convert that to Assembly.





The program consists of:
	-a .y file for Yacc, the main file is located inside this .y file.
	-a .l file for flex
	-a .c/h file for the abstract tree data struct itself. 
	-a .c/h file for the Symbol Table.
	-a .c/h file for the TypeChecking.
	-a .c/h file for the IR code generation.   



1 = Error Free Beautiful tree
./cflatc -a < 1.cb
./cflatc -s < 1.cb
./cflatc -c < 1.cb

2-4 = About 3 Errors










