Horia "Ryder" Stancescu
hstances - 0721385

To Run:
	python a3.py boardPath.txt


Please do not supply invalid boards such as OldWoman2, where 
pawns result in varying permutations as they were meant to be upgraded on the prior turn
when they moved to the upgrade position.

Also for states where a gorilla or catapult flings a pawn, they will also get upgraded as per spec.
For the gorilla this includes enemy pawns.



As requested in the email all board.000 -> board.NNN files will be generated in the same folder with the main python
class.