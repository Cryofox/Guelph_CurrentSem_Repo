#ifndef ASSEMBLY
#define ASSEMBLY
#include <stdlib.h>
#include <stdio.h>
#include "SymbolTable.h"
#include "AbstractTree.h"
#include "IR_Instructions.h"
void CreateAssembly();

#endif 