Horia “Ryder” Stancescu
hstances - 0721385

To Compile: make

To Compile/Launch: make run

TO RUN (after compiled): ./a1

To Remove OBJS + Exe: make clean


A3. Oh Boy Networks!

Server client work as described in the spec. 1 Server relays all information needed to clients. Clients display their view via the angle of the server player’s gun.




Map:
 The Player (You) on any client is Colored BLUE. Shots are coloured Pink. And the Terrain
is a mossy dark green.

Depending on Client:
	You - Blue
	Friends - Light Green
	Projectiles - Pink

                        



    





